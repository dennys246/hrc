# hrc
This repository contains the hemodynamic response convolver (hrc) tool which can be used on preprocessed mne nirx objects to extract the hemodynamic response function. Within this library also contains the HRF object that can be used to dynamically generate or load synthetic HRF filters for use in convolution. 

To use this repository