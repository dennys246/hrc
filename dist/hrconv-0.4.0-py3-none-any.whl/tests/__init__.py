from tests.test_batch import test

test()